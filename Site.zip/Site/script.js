// scripts.js
const whatsappicon = document.querySelector('.whatsapp-icon');

window.addEventListener('scroll', () => {
  if (window.scrollY > 100) {
    whatsappicon.classList.add('visible');
  } else {
    whatsappicon.classList.remove('visible');
  }
});
